
//nesta arquivo em breve estara a requisição e conversação com o GNU GO. Nesta parte do projeto tb estara contida a iteração com o MONGODB

//é o tabuleiro atual com a disposição das peças atuais.
var tabuleiro = 
{
	score:1,
	places:[]
}

var references = []//são refencias, será usada para definir para cada uma das casas quem são as suas referencias.
var count = 0;//usado para saber qual é o indice no vetor das peças
for(var i = 0; i < 9; i++) // tamanho 9 x 9 -  MATRIZ
{
	for(var j = 0; j < 9; j++)
	{
		var aPlace = new place();// o metrodo PLACE é basicamente a ESTRUTURA DE CADA UMA DAS CASAS, e contem informações como: quem está ocupando ela, 
		//quem são as adjacencias e afins
		
		aPlace.casa = i+'.'+j; // as casas são chamadas de acordo com a coluna e linha a qual pertencem
		aPlace.ocupada = false;// é true, quando existe uma peça alocada naquela dada casa
		aPlace.jogador = null;// informa se é uma casa ocupada por peças: 'white' ou 'black'

		var reference = []; //usado para fazer a referencia.

		if(j+1 < 9)
			reference.push(count+1)
		if(j-1 >= 0)
			reference.push(count-1)

		if(i+1 < 9)
		{
			reference.push(count+9);
		}
		if(i-1 >= 0)
		{
			reference.push(count-9);
		}
		
		references.push(reference);// para cada casa no tabuleiro é armazenada o INDICE no vetor de tabuleiro.places, e posteriormente é usado para fazer as peças terem a referencia
		//de suas adjacencias
		tabuleiro.places.push( aPlace );//adiciona ao tabuleiro a peça.;
		count++;//contador de casas
	}		
}

tabuleiro.score = 0;//pontuação do cenário atual


//no for abaixo adiciono a referencia entre as peças e suas adjacencias
for(var i =0; i < tabuleiro.places.length; i++)
{
	for(var j = 0; j < references[i].length; j++)
	{
		var indice = parseInt(references[i][j]);
		tabuleiro.places[i].adjacencias.push(tabuleiro.places[indice])
	}
}
umberProt( tabuleiro );//chamo a função "Protagonista de tudo", ela está no arquivo: js/umberPrototype.js